
import clr

clr.AddReference("CSharp.Script.dll")

from CSharp.Script import *
from CSScriptLoader import loadcs

