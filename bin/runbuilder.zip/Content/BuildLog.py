import wpf
import clr

#clr.AddReference("System.Windows.Controls")

#from System.Windows.Controls import UserControl


from FirstFloor.ModernUI.App import CTUtils, CTUserContorl

class BuildLog(CTUserContorl):
    def __init__(self):
        wpf.LoadComponent(self, 'Content/BuildLog.xaml')

    def log(self, s):
        self.LogerOut.AppendText(s)




